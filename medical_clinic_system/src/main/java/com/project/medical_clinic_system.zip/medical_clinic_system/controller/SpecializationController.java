package com.project.medical_clinic_system.controller;

import com.project.medical_clinic_system.dto.request.CreateSpecializationRequest;
import com.project.medical_clinic_system.dto.response.SpecializationResponse;
import com.project.medical_clinic_system.service.SpecializationService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/specialization")
public class SpecializationController {

    private final SpecializationService specializationService;

    public SpecializationController(SpecializationService specializationService) {
        this.specializationService = specializationService;
    }

    @PostMapping
    public SpecializationResponse createSpecialization(
            @Valid @RequestBody CreateSpecializationRequest request) {
        return specializationService.createSpecialization(request);
    }

    @PutMapping("/{specializationID}")
    public SpecializationResponse updateSpecializationByID(
            @PathVariable UUID specializationID,
            @Valid @RequestBody CreateSpecializationRequest request) {
        return specializationService.updateSpecializationByID(specializationID, request);
    }

    @DeleteMapping("/{specializationID}")
    public String deleteSpecializationByID(
            @PathVariable UUID specializationID) {
        return specializationService.deleteSpecializationByID(specializationID);
    }
}