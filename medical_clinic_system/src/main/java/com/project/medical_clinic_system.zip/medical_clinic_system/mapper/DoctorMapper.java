package com.project.medical_clinic_system.mapper;

import com.project.medical_clinic_system.dto.response.DoctorResponse;
import com.project.medical_clinic_system.model.Doctor;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;


@Component
public class DoctorMapper {
    public DoctorResponse toResponse(Doctor doctor) {
        return new DoctorResponse(
                doctor.getId(),
                doctor.getName(),
                doctor.getEmail(),
                doctor.getSpecialization() != null ? doctor.getSpecialization().getName() : null
        );
    }

    public List<DoctorResponse> toResponse(List<Doctor> doctors) {
        List<DoctorResponse> responses = new ArrayList<>();

        for (Doctor doctor : doctors ) {
            responses.add(toResponse(doctor));
        }

        return responses;
    }
}
