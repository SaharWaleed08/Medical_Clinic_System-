package com.project.medical_clinic_system.repository;

import com.project.medical_clinic_system.model.Doctor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import java.util.UUID;

@Repository
public interface DoctorRepository extends JpaRepository<Doctor, UUID> {
    Page<Doctor> findByNameContainingIgnoreCase(String name, Pageable pageable);
    boolean existsByEmail(String email);
}